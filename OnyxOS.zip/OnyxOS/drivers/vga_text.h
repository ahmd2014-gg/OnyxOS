#ifndef VGA_TEXT_H
#define VGA_TEXT_H

void vga_print(const char* str);
void vga_clear();

#endif
