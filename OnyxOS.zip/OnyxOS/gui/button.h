#ifndef BUTTON_H
#define BUTTON_H

#include <stdint.h>

void draw_button(uint16_t x, uint16_t y, uint16_t w, uint16_t h, const char* label);

#endif
