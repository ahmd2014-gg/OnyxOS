#ifndef WINDOW_H
#define WINDOW_H

#include <stdint.h>

void draw_window(uint16_t x, uint16_t y, uint16_t w, uint16_t h, const char* title);

#endif
